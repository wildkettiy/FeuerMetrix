local displayFrame = CreateFrame("Frame", "FeuerstuhlDisplayFrame", UIParent)
displayFrame:SetSize(160, 85)
displayFrame:SetPoint("CENTER")
displayFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
displayFrame:SetBackdropColor(0, 0, 0, 0.85)
displayFrame:SetMovable(true)
displayFrame:EnableMouse(true)
displayFrame:RegisterForDrag("LeftButton")
displayFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
displayFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
displayFrame:Hide()

local title = displayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
title:SetPoint("TOP", 0, -8)
title:SetText("|cFFFFFF00FeuerMetrix:|r")

local speedText = displayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
speedText:SetPoint("TOP", 0, -22)

local tripText = displayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
tripText:SetPoint("TOP", 0, -48)
tripText:SetTextColor(0.7, 0.7, 1)

local totalText = displayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
totalText:SetPoint("TOP", 0, -64)
totalText:SetTextColor(1, 0.8, 0)

local ZonenDaten = {
    ["Dalaran"] = 750, ["CrystalsongForest"] = 1580, ["BoreanTundra"] = 2080,
    ["HowlingFjord"] = 2000, ["Dragonblight"] = 2250, ["GrizzlyHills"] = 1910,
    ["ZulDrak"] = 2000, ["SholazarBasin"] = 1910, ["StormPeaks"] = 2160,
    ["Icecrown"] = 2250, ["LakeWintergrasp"] = 1750, ["DEFAULT"] = 1916
}

local Meilensteine = {100, 250, 500, 750, 1000, 1500, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000}

local FeuerstuhlTag = 0 
local lastX, lastY = 0, 0
local isTracking = false
local aktuellerFaktor = ZonenDaten["DEFAULT"]

local function CheckAchievements(gesamteMeter)
    local aktuelleKM = gesamteMeter / 1000
    for _, ziel in ipairs(Meilensteine) do
        if aktuelleKM >= ziel and (FeuerstuhlLastM or 0) < ziel then
            FeuerstuhlLastM = ziel
            
            PlaySoundFile("Sound\\Interface\\LevelUp.wav")
            
            print("|cFFFFFF00==========================================|r")
            print("|cFF00FF00[FeuerMetrix ERFOLG]|r")
            print("|cFFFFFF00Wahnsinn! Du hast die |r|cFF00FF00" .. ziel .. " km|r |cFFFFFF00Marke geknackt!|r")
            print("|cFFFFFF00Weiterhin gute Fahrt auf deinem Feuerstuhl!|r")
            print("|cFFFFFF00==========================================|r")
        end
    end
end

local logicFrame = CreateFrame("Frame")
logicFrame:RegisterEvent("ADDON_LOADED")
logicFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
logicFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

logicFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == "FeuerstuhlTracker" then
        if FeuerstuhlKilometer == nil then FeuerstuhlKilometer = 0 end
        if FeuerstuhlLastM == nil then FeuerstuhlLastM = 0 end
    end
    local zoneKey = GetMapInfo()
    aktuellerFaktor = ZonenDaten[zoneKey] or ZonenDaten["DEFAULT"]
end)

logicFrame:SetScript("OnUpdate", function(self, elapsed)
    local mounted = false
    for i = 1, 40 do
        local name = UnitBuff("player", i)
        if not name then break end
        if name == "Feuerstuhl" or name == "Chopper des Robogenieurs" then
            mounted = true break
        end
    end

    if mounted then
        if not displayFrame:IsVisible() then displayFrame:Show() end
        local x, y = GetPlayerMapPosition("player")
        if x == 0 and y == 0 then SetMapToCurrentZone() x, y = GetPlayerMapPosition("player") end

        if x > 0 and y > 0 then
            if isTracking and lastX > 0 then
                local dx, dy = x - lastX, y - lastY
                local distMeter = math.sqrt(dx*dx + dy*dy) * aktuellerFaktor
                
                if distMeter > 0.01 and distMeter < 60 then 
                    FeuerstuhlKilometer = FeuerstuhlKilometer + distMeter
                    FeuerstuhlTag = FeuerstuhlTag + distMeter
                    
                    local speed = (distMeter / elapsed) * 10
                    if speed > 150 then speed = 0 end 
                    
                    if speed >= 64.5 then
                        speedText:SetTextColor(1, 0, 0)
                        speedText:SetText(string.format("! %.1f km/h !", speed))
                    else
                        speedText:SetTextColor(1, 1, 1)
                        speedText:SetText(string.format("%.1f km/h", speed))
                    end
                    
                    tripText:SetText(string.format("Trip: %.2f km", FeuerstuhlTag / 1000))
                    totalText:SetText(string.format("KM-Stand: %.1f km", FeuerstuhlKilometer / 1000))
                    
                    CheckAchievements(FeuerstuhlKilometer)
                end
            else
                speedText:SetTextColor(1, 1, 1)
                speedText:SetText("0.0 km/h")
            end
            lastX, lastY = x, y
            isTracking = true
        end
    else
        if displayFrame:IsVisible() then displayFrame:Hide() end
        isTracking = false
        lastX, lastY = 0, 0
    end
end)

SLASH_STUHLRESET1 = "/fmreset"
SlashCmdList["STUHLRESET"] = function(msg)
    if msg == "trip" then
        FeuerstuhlTag = 0
        print("|cFF00FF00Tageskilometer auf 0 gesetzt.|r")
    else
        FeuerstuhlKilometer = 0
        FeuerstuhlTag = 0
        FeuerstuhlLastM = 0
        print("|cFF00FF00Alle Zähler und Erfolge auf 0 gesetzt.|r")
    end
end